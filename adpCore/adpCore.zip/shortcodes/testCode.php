<?php
$nameVal = isset($name) ? $name : '';
echo '<p>A test shortcode '.$nameVal.'</p>';
echo $content;